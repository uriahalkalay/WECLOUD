import os
import select
import signal
import socket
import sqlite3
import hashlib
import secrets
import time
import rsa
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import Common

CHUNK_SIZE = 1000
DB_FILE = "cloud.db"
STORAGE_DIR = "storage"
PORT = 8080

MAX_FAILED_LOGINS = 5
LOCKOUT_SECONDS = 60

os.makedirs(STORAGE_DIR, exist_ok=True)

class CloudInfrastructure:
    """מחלקה זו מרכזת את כל הפעולות הכלליות של השרת כמו מסד נתונים וניהול משתמשים בסיסי"""
    def __init__(self):
        self.setup_database()
        self.clients = []
        self.buffers = {}
        self.send_queue = {}

    def open_db(self):
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row
        return conn

    def setup_database(self):
        db = self.open_db()
        c = db.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT, salt TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS files (id INTEGER PRIMARY KEY, owner_id INTEGER, filename TEXT, file_path TEXT, file_size INTEGER, file_hash TEXT, is_private INTEGER DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS file_shares (id INTEGER PRIMARY KEY, file_id INTEGER, user_id INTEGER, UNIQUE(file_id, user_id))""")
        db.commit()
        db.close()

    def hash_password(self, password, salt):
        return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000).hex()

    def get_user_id(self, username):
        db = self.open_db()
        row = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
        db.close()
        return row["id"] if row else None

class Server(CloudInfrastructure):
    def __init__(self):
        super().__init__()

        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind(("0.0.0.0", PORT))
        self.server.listen()
        self.server.setblocking(False)

        self.clients.append(self.server)
        self.sessions = {}      # sock -> user_id
        self.usernames = {}     # sock -> username
        self.aes_keys = {}      # sock -> AES key
        self.uploads = {}       # sock -> accumulated upload bytes

        self.failed_logins = {}

        self.pub, self.priv = rsa.newkeys(2048)
        self.running = True

        print(f"Server listening on port {PORT}...")
        signal.signal(signal.SIGINT, self.shutdown)

    def shutdown(self, *args):
        print("\nShutting down server...")
        for c in self.clients:
            try:
                c.close()
            except Exception:
                pass
        os._exit(0)

    def send(self, sock, cmd, data):
        msg = Common.build_message(cmd, data)
        self.send_queue.setdefault(sock, []).append(msg)

    def disconnect(self, sock):
        if sock in self.clients:
            self.clients.remove(sock)
        for d in [self.buffers, self.send_queue, self.sessions, self.usernames, self.aes_keys, self.uploads]:
            d.pop(sock, None)
        try:
            sock.close()
        except Exception:
            pass

    def is_logged_in(self, sock):
        if sock not in self.sessions:
            self.send(sock, Common.CMD_LOGIN_FAIL, b"Please login first")
            return False
        return True

    def create_user(self, username, password):
        salt = secrets.token_hex(16)
        try:
            db = self.open_db()
            db.execute("INSERT INTO users VALUES (NULL,?,?,?)", (username, self.hash_password(password, salt), salt))
            db.commit()
            db.close()
            return True
        except sqlite3.IntegrityError:
            return False

    def check_user(self, username, password):
        db = self.open_db()
        row = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        db.close()
        if not row:
            return None
        if self.hash_password(password, row["salt"]) == row["password_hash"]:
            return row["id"]
        return None

    def handle_register(self, sock, payload):
        try:
            if not payload or len(payload) < 2:
                self.send(sock, Common.CMD_REG_FAIL, b"payload too short")
                return
            username_len = payload[0]
            if len(payload) < 1 + username_len:
                self.send(sock, Common.CMD_REG_FAIL, b"invalid format")
                return
            username = payload[1: 1 + username_len].decode("utf-8").strip()
            password = payload[1 + username_len:].decode("utf-8").strip()
            if not username or not password:
                self.send(sock, Common.CMD_REG_FAIL, b"empty fields")
                return
            if self.create_user(username, password):
                self.send(sock, Common.CMD_REG_OK, b"ok")
            else:
                self.send(sock, Common.CMD_REG_FAIL, b"user exists")
        except Exception as e:
            print(f"Register error: {e}")
            self.send(sock, Common.CMD_REG_FAIL, b"internal server error")

    def handle_login(self, sock, payload):
        ip = sock.getpeername()[0]
        now = time.time()
        history = [t for t in self.failed_logins.get(ip, []) if now - t < LOCKOUT_SECONDS]
        self.failed_logins[ip] = history
        if len(history) >= MAX_FAILED_LOGINS:
            self.send(sock, Common.CMD_RATE_LIMITED, b"Too many attempts. Wait a minute.")
            return
        try:
            if len(payload) < 258:
                self.send(sock, Common.CMD_LOGIN_FAIL, b"bad packet")
                return
            aes_key = rsa.decrypt(payload[:256], self.priv)
            l = payload[256]
            username = payload[257: 257 + l].decode()
            password = payload[257 + l:].decode()
        except Exception as e:
            print(f"Login handshake error: {e}")
            self.send(sock, Common.CMD_LOGIN_FAIL, b"handshake failed")
            return

        user_id = self.check_user(username, password)
        if not user_id:
            self.failed_logins.setdefault(ip, []).append(now)
            self.send(sock, Common.CMD_LOGIN_FAIL, b"wrong credentials")
            return
        self.sessions[sock] = user_id
        self.usernames[sock] = username
        self.aes_keys[sock] = aes_key
        self.send(sock, Common.CMD_LOGIN_OK, b"ok")

    def handle_upload_chunk(self, sock, payload):
        if not self.is_logged_in(sock): return
        try:
            nonce, tag, enc = payload[:16], payload[-16:], payload[16:-16]
            cipher = AES.new(self.aes_keys[sock], AES.MODE_EAX, nonce=nonce)
            data = cipher.decrypt_and_verify(enc, tag)
            self.uploads.setdefault(sock, b"")
            self.uploads[sock] += data
            if len(data) < CHUNK_SIZE: self.save_file(sock)
        except Exception as e: print(f"Upload chunk error: {e}")

    def save_file(self, sock):
        raw = self.uploads.pop(sock, b"")
        if not raw: return
        try:
            is_private, name_len = raw[0], raw[1]
            filename = os.path.basename(raw[2: 2 + name_len].decode())
            content = raw[2 + name_len:]
            prefix = get_random_bytes(6).hex()
            path = os.path.join(STORAGE_DIR, f"{prefix}_{filename}")
            with open(path, "wb") as f: f.write(content)
            db = self.open_db()
            db.execute("INSERT INTO files VALUES (NULL,?,?,?,?,?,?)",
                       (self.sessions[sock], filename, path, len(content),
                        hashlib.sha256(content).hexdigest(), is_private))
            db.commit(); db.close()
            self.send(sock, Common.CMD_UPLOAD_OK, b"done")
        except Exception as e: print(f"Save file error: {e}")

    def handle_list(self, sock, payload):
        if not self.is_logged_in(sock): return
        uid = self.sessions[sock]
        db = self.open_db()
        rows = db.execute("""
            SELECT f.*, (SELECT 1 FROM file_shares fs WHERE fs.file_id=f.id AND fs.user_id=?) as shared
            FROM files f
            WHERE f.owner_id=? OR f.is_private=0
               OR EXISTS (SELECT 1 FROM file_shares fs WHERE fs.file_id=f.id AND fs.user_id=?)
        """, (uid, uid, uid)).fetchall()
        db.close()
        lines = [f"{r['filename']}|{r['is_private']}|{1 if r['owner_id'] == uid else 0}|{1 if r['shared'] else 0}" for r in rows]
        self.send(sock, Common.CMD_FILE_LIST, "\n".join(lines).encode())

    def handle_get_file(self, sock, payload):
        if not self.is_logged_in(sock): return
        uid, filename = self.sessions[sock], payload.decode(errors="replace").strip()
        db = self.open_db()
        row = db.execute("SELECT * FROM files WHERE filename=? AND (owner_id=? OR is_private=0 OR EXISTS (SELECT 1 FROM file_shares WHERE file_id=id AND user_id=?))", (filename, uid, uid)).fetchone()
        db.close()
        if not row:
            self.send(sock, Common.CMD_FILE_NOT_FOUND, b"not found or access denied")
            return
        try:
            with open(row["file_path"], "rb") as f: content = f.read()
        except OSError:
            self.send(sock, Common.CMD_FILE_NOT_FOUND, b"file missing on disk")
            return
        if hashlib.sha256(content).hexdigest() != row["file_hash"]:
            self.send(sock, Common.CMD_INTEGRITY_FAIL, b"hash mismatch")
            return
        offset = 0
        while offset < len(content):
            chunk = content[offset: offset + CHUNK_SIZE]
            cipher = AES.new(self.aes_keys[sock], AES.MODE_EAX)
            ct, tag = cipher.encrypt_and_digest(chunk)
            self.send(sock, Common.CMD_FILE_CHUNK_SRV, cipher.nonce + ct + tag)
            offset += CHUNK_SIZE

    def handle_delete(self, sock, payload):
        if not self.is_logged_in(sock): return
        uid, filename = self.sessions[sock], payload.decode(errors="replace").strip()
        db = self.open_db()
        row = db.execute("SELECT * FROM files WHERE filename=? AND owner_id=?", (filename, uid)).fetchone()
        if not row:
            db.close(); self.send(sock, Common.CMD_DELETE_FAIL, b"not found or not your file"); return
        try: os.remove(row["file_path"])
        except OSError: pass
        db.execute("DELETE FROM file_shares WHERE file_id=?", (row["id"],))
        db.execute("DELETE FROM files WHERE id=?", (row["id"],))
        db.commit(); db.close()
        self.send(sock, Common.CMD_DELETE_OK, b"deleted")

    def handle_rename(self, sock, payload):
        if not self.is_logged_in(sock): return
        try:
            l, old_name = payload[0], payload[1: 1 + payload[0]].decode()
            new_name = os.path.basename(payload[1 + payload[0]:].decode())
            if not new_name: self.send(sock, Common.CMD_RENAME_FAIL, b"empty name"); return
            db = self.open_db()
            db.execute("UPDATE files SET filename=? WHERE filename=? AND owner_id=?", (new_name, old_name, self.sessions[sock]))
            db.commit(); db.close()
            self.send(sock, Common.CMD_RENAME_OK, b"ok")
        except Exception as e: print(f"Rename error: {e}"); self.send(sock, Common.CMD_RENAME_FAIL, b"error")

    def handle_share(self, sock, payload):
        if not self.is_logged_in(sock): return
        try:
            l, filename = payload[0], payload[1: 1 + payload[0]].decode()
            target_user = payload[1 + payload[0]:].decode().strip()
            target_id = self.get_user_id(target_user)
            if not target_id: self.send(sock, Common.CMD_SHARE_FAIL, b"user not found"); return
            db = self.open_db()
            file_row = db.execute("SELECT id FROM files WHERE filename=? AND owner_id=?", (filename, self.sessions[sock])).fetchone()
            if not file_row:
                db.close(); self.send(sock, Common.CMD_SHARE_FAIL, b"file not found or not your file"); return
            db.execute("INSERT OR IGNORE INTO file_shares VALUES (NULL,?,?)", (file_row["id"], target_id))
            db.commit(); db.close()
            self.send(sock, Common.CMD_SHARE_OK, f"Shared with {target_user}".encode())
        except Exception as e: print(f"Share error: {e}"); self.send(sock, Common.CMD_SHARE_FAIL, b"error")

    def run(self):
        while self.running:
            readable, writable, _ = select.select(self.clients, self.clients, [], 1)
            for sock in readable:
                if sock is self.server:
                    client, addr = self.server.accept()
                    client.setblocking(False)
                    self.clients.append(client)
                    self.buffers[client] = b""
                    client.send(self.pub.save_pkcs1())
                    print(f"Connected: {addr}")
                else:
                    try:
                        data = sock.recv(4096)
                        if not data: self.disconnect(sock); continue
                        self.buffers[sock] += data
                        while True:
                            cmd, payload = Common.try_parse_message(self.buffers[sock])
                            if cmd is None: break
                            self.buffers[sock] = self.buffers[sock][Common.HEADER_SIZE + len(payload):]
                            handlers = {
                                Common.CMD_REGISTER:    self.handle_register,
                                Common.CMD_LOGIN:       self.handle_login,
                                Common.CMD_FILE_CHUNK:  self.handle_upload_chunk,
                                Common.CMD_LIST_FILES:  self.handle_list,
                                Common.CMD_GET_FILE:    self.handle_get_file,
                                Common.CMD_DELETE_FILE: self.handle_delete,
                                Common.CMD_RENAME_FILE: self.handle_rename,
                                Common.CMD_SHARE_FILE:  self.handle_share,
                                Common.CMD_LOGOUT:      self.disconnect,
                            }
                            if cmd in handlers: handlers[cmd](sock, payload)
                    except Exception as e: print(f"Client error: {e}"); self.disconnect(sock)
            for sock in writable:
                if sock in self.send_queue and self.send_queue[sock]:
                    try: sock.sendall(self.send_queue[sock].pop(0))
                    except Exception: self.disconnect(sock)

if __name__ == "__main__":
    Server().run()