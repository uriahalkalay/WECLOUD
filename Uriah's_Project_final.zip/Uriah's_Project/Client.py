import os
import socket
import threading
import rsa
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import customtkinter as ctk
from tkinter import filedialog
import hashlib
import Common

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8080
CHUNK_SIZE = 1000


class CloudConnection:
    def __init__(self):
        self.sock = None
        self.aes_key = None
        self.public_key = None
        self._lock = threading.Lock()
        self._buf = b""

    def connect(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10)
        try:
            sock.connect((SERVER_HOST, SERVER_PORT))
            raw = b""
            while b"-----END RSA PUBLIC KEY-----" not in raw:
                chunk = sock.recv(4096)
                if not chunk:
                    raise ConnectionError("Server closed during handshake")
                raw += chunk
            self.public_key = rsa.PublicKey.load_pkcs1(raw)
            self.aes_key = get_random_bytes(32)
            sock.settimeout(None)
            self.sock = sock
            self._buf = b""
        except Exception:
            try:
                sock.close()
            except:
                pass
            self.sock = None
            raise

    def close(self):
        with self._lock:
            if self.sock:
                try:
                    self.sock.sendall(Common.build_message(Common.CMD_LOGOUT, b""))
                except:
                    pass
                try:
                    self.sock.close()
                except:
                    pass
            self.sock = None
            self.aes_key = None
            self.public_key = None
            self._buf = b""

    def send(self, cmd: int, data: bytes):
        with self._lock:
            if not self.sock: raise ConnectionError("Not connected")
            self.sock.sendall(Common.build_message(cmd, data))

    def recv_one(self):
        while True:
            cmd, payload = Common.try_parse_message(self._buf)
            if cmd is not None:
                self._buf = self._buf[Common.HEADER_SIZE + len(payload):]
                return cmd, payload
            try:
                chunk = self.sock.recv(8192)
            except OSError as e:
                raise ConnectionError(f"Socket error: {e}") from e
            if not chunk:
                raise ConnectionError("Server closed connection")
            self._buf += chunk

    @property
    def is_connected(self) -> bool:
        return self.sock is not None


class EncryptedFileClient:
    def __init__(self):
        self.conn = CloudConnection()
        self.logged_in = False
        self._username = ""
        self.selected_file = None
        self._action_btns = []
        self.all_entries = []  # רשימה לשמירת כל הקבצים לצורך חיפוש מהיר

        # יצירת החלון קודם כדי למנוע שגיאת AttributeError
        self.window = ctk.CTk()
        self.mode_var = ctk.IntVar(value=0)
        ctk.set_appearance_mode("light")

        self.window.title("Uriah's Cloud")
        self.window.geometry("750x700")  # הגדלתי מעט את הגובה לטובת שורת החיפוש
        self.window.resizable(False, False)
        self.window.protocol("WM_DELETE_WINDOW", self._on_close)
        self._build_auth_screen()

    def _on_close(self):
        if self.logged_in:
            try:
                self.conn.close()
            except:
                pass
        self.window.destroy()

    def _status(self, text, color=None):
        def _set():
            if hasattr(self, "status_label"):
                kw = {"text": f"Status: {text}"}
                if color: kw["text_color"] = color
                self.status_label.configure(**kw)

        self.window.after(0, _set)

    def _clear_window(self):
        self._action_btns.clear()
        for w in self.window.winfo_children():
            w.destroy()

    def _set_buttons_enabled(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        for btn in self._action_btns:
            try:
                btn.configure(state=state)
            except:
                pass

    def _handle_disconnect(self, reason: str = "Server disconnected"):
        self.logged_in = False
        try:
            self.conn.close()
        except:
            pass

        def _ui_update():
            self._set_buttons_enabled(False)
            self._status(f"⚠ {reason} — please restart or log in again.", "#E24B4A")

        self.window.after(0, _ui_update)

    def _build_auth_screen(self):
        self._clear_window()
        frame = ctk.CTkFrame(self.window, corner_radius=12)
        frame.pack(padx=40, pady=40, fill="both", expand=True)

        ctk.CTkLabel(frame, text="Uriah's Cloud", font=ctk.CTkFont(size=24, weight="bold")).pack(pady=(24, 28))

        ctk.CTkLabel(frame, text="Username").pack(anchor="w", padx=36)
        self.entry_username = ctk.CTkEntry(frame, width=320, height=36)
        self.entry_username.pack(padx=36, pady=(0, 14))

        ctk.CTkLabel(frame, text="Password").pack(anchor="w", padx=36)
        self.entry_password = ctk.CTkEntry(frame, show="-", width=320, height=36)
        self.entry_password.pack(padx=36, pady=(0, 22))
        self.entry_password.bind("<Return>", lambda _: threading.Thread(target=self._do_login, daemon=True).start())

        btn_row = ctk.CTkFrame(frame, fg_color="transparent")
        btn_row.pack()

        login_btn = ctk.CTkButton(btn_row, text="Login", width=140,
                                  command=lambda: threading.Thread(target=self._do_login, daemon=True).start())
        login_btn.pack(side="left", padx=10)
        self._action_btns.append(login_btn)

        reg_btn = ctk.CTkButton(btn_row, text="Register", width=140, fg_color=("gray70", "gray35"),
                                hover_color=("gray60", "gray45"),
                                command=lambda: threading.Thread(target=self._do_register, daemon=True).start())
        reg_btn.pack(side="left", padx=10)
        self._action_btns.append(reg_btn)

        self.status_label = ctk.CTkLabel(frame, text="Status: Waiting…", anchor="w", wraplength=460,
                                         font=ctk.CTkFont(size=12))
        self.status_label.pack(padx=36, pady=(24, 0), fill="x")

    def _build_main_screen(self):
        self._clear_window()
        root = ctk.CTkFrame(self.window, corner_radius=12)
        root.pack(padx=16, pady=16, fill="both", expand=True)

        # Header עם שם משתמש ו-Dark Mode Switch
        top = ctk.CTkFrame(root, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(top, text=f"Uriah's Cloud  —  {self._username}", font=ctk.CTkFont(size=17, weight="bold")).pack(
            side="left")

        ctk.CTkButton(top, text="Logout", width=72, height=28, command=self._do_logout).pack(side="right", padx=(10, 0))

        self.mode_switch = ctk.CTkSwitch(top, text="Dark", command=self.toggle_mode, variable=self.mode_var, onvalue=1,
                                         offvalue=0, width=50)
        self.mode_switch.pack(side="right")

        # Upload Area
        upload_card = ctk.CTkFrame(root, corner_radius=8)
        upload_card.pack(fill="x", padx=12, pady=(6, 4))
        pick_row = ctk.CTkFrame(upload_card, fg_color="transparent")
        pick_row.pack(fill="x", padx=10, pady=(8, 2))
        self.file_label = ctk.CTkLabel(pick_row, text="No file selected", anchor="w")
        self.file_label.pack(side="left", expand=True, fill="x")
        select_btn = ctk.CTkButton(pick_row, text="Select File", width=105, height=28, command=self._pick_file)
        select_btn.pack(side="right")
        self._action_btns.append(select_btn)

        self.progress = ctk.CTkProgressBar(root, orientation="horizontal")
        self.progress.set(0)
        self.progress.pack(fill="x", padx=12, pady=5)

        opt_row = ctk.CTkFrame(upload_card, fg_color="transparent")
        opt_row.pack(fill="x", padx=10, pady=(2, 8))
        self.private_var = ctk.BooleanVar(value=False)
        ctk.CTkSwitch(opt_row, text="Private", variable=self.private_var, font=ctk.CTkFont(size=12)).pack(side="left")
        upload_btn = ctk.CTkButton(opt_row, text="Upload", width=90, height=28,
                                   command=lambda: threading.Thread(target=self._upload_file, daemon=True).start())
        upload_btn.pack(side="right")
        self._action_btns.append(upload_btn)

        # Storage Status
        self.storage_frame = ctk.CTkFrame(root, fg_color="transparent")
        self.storage_frame.pack(fill="x", padx=12, pady=(5, 0))
        self.storage_label = ctk.CTkLabel(self.storage_frame, text="Storage Usage: 0 MB / 100 MB",
                                          font=ctk.CTkFont(size=11))
        self.storage_label.pack(side="top", anchor="w")
        self.storage_bar = ctk.CTkProgressBar(self.storage_frame, width=300, height=10)
        self.storage_bar.set(0)
        self.storage_bar.pack(fill="x", pady=(2, 10))

        # --- תיבת חיפוש (Search Box) ---
        search_frame = ctk.CTkFrame(root, fg_color="transparent")
        search_frame.pack(fill="x", padx=12, pady=(5, 5))
        self.search_entry = ctk.CTkEntry(search_frame, placeholder_text="🔍 Search files by name...", height=35)
        self.search_entry.pack(fill="x", expand=True)
        self.search_entry.bind("<KeyRelease>", lambda e: self._render_files())

        # Files Header
        hdr = ctk.CTkFrame(root, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(8, 0))
        ctk.CTkLabel(hdr, text="Files on server", font=ctk.CTkFont(size=14, weight="bold")).pack(side="left")
        refresh_btn = ctk.CTkButton(hdr, text="⟳ Refresh", width=80, height=26,
                                    command=lambda: threading.Thread(target=self._refresh_list, daemon=True).start())
        refresh_btn.pack(side="right")
        self._action_btns.append(refresh_btn)

        # Browser
        self.browser_frame = ctk.CTkScrollableFrame(root, corner_radius=8, height=210)
        self.browser_frame.pack(fill="both", expand=True, padx=12, pady=(2, 6))
        self.browser_frame.columnconfigure(0, weight=1)

        self.status_label = ctk.CTkLabel(root, text="Status: Ready", anchor="w", font=ctk.CTkFont(size=12),
                                         text_color=("gray40", "gray60"))
        self.status_label.pack(fill="x", padx=14, pady=(0, 8))

        threading.Thread(target=self._refresh_list, daemon=True).start()

    def _ensure_connected(self):
        if not self.conn.is_connected: self.conn.connect()

    def _safe_send_recv(self, send_cmd, send_data: bytes):
        self.conn.send(send_cmd, send_data)
        return self.conn.recv_one()

    def toggle_mode(self):
        if self.mode_var.get() == 1:
            ctk.set_appearance_mode("dark")
        else:
            ctk.set_appearance_mode("light")

    def _do_register(self):
        username = self.entry_username.get().strip()
        password = self.entry_password.get()
        if not username or not password:
            self._status("Enter a username and password")
            return
        try:
            self._ensure_connected()
            uname_b = username.encode('utf-8')
            cmd, resp = self._safe_send_recv(Common.CMD_REGISTER,
                                             len(uname_b).to_bytes(1, "big") + uname_b + password.encode())
            if cmd == Common.CMD_REG_OK:
                self._status("Registered! Now log in.", "#1D9E75")
            else:
                self._status(f"Register failed: {resp.decode()}", "#E24B4A")
        except Exception as e:
            self._status(f"Error: {e}", "#E24B4A")

    def _do_login(self):
        username = self.entry_username.get().strip()
        password = self.entry_password.get()
        if not username or not password:
            self._status("Enter a username and password")
            return
        try:
            self._ensure_connected()
            uname_b = username.encode()
            payload = rsa.encrypt(self.conn.aes_key, self.conn.public_key) + len(uname_b).to_bytes(1,
                                                                                                   "big") + uname_b + password.encode()
            cmd, resp = self._safe_send_recv(Common.CMD_LOGIN, payload)
            if cmd == Common.CMD_LOGIN_OK:
                self.logged_in = True
                self._username = username
                self.window.after(0, self._build_main_screen)
            else:
                self._status(f"Login failed: {resp.decode()}", "#E24B4A")
        except Exception as e:
            self._status(f"Error: {e}", "#E24B4A")

    def _do_logout(self):
        self.conn.close()
        self.conn = CloudConnection()
        self.logged_in = False
        self.window.after(0, self._build_auth_screen)

    def _pick_file(self):
        path = filedialog.askopenfilename()
        if path:
            self.selected_file = path
            self.file_label.configure(text=os.path.basename(path))

    def _upload_file(self):
        if not self.selected_file: return
        try:
            filename = os.path.basename(self.selected_file)
            with open(self.selected_file, "rb") as f:
                content = f.read()
            fname_b = filename.encode()
            raw_data = (1 if self.private_var.get() else 0).to_bytes(1, "big") + len(fname_b).to_bytes(1,
                                                                                                       "big") + fname_b + content

            total, offset = len(raw_data), 0
            while offset < total:
                chunk = raw_data[offset: offset + CHUNK_SIZE]
                cipher = AES.new(self.conn.aes_key, AES.MODE_EAX)
                ct, tag = cipher.encrypt_and_digest(chunk)
                self.conn.send(Common.CMD_FILE_CHUNK, cipher.nonce + ct + tag)
                offset += CHUNK_SIZE
                self.window.after(0, lambda p=min(1.0, offset / total): self.progress.set(p))

            cmd, _ = self.conn.recv_one()
            if cmd == Common.CMD_UPLOAD_OK:
                self._status(f"Uploaded: {filename}", "#1D9E75")
                threading.Thread(target=self._refresh_list, daemon=True).start()
        except:
            pass

    def _refresh_list(self):
        try:
            cmd, payload = self._safe_send_recv(Common.CMD_LIST_FILES, b"")
            if cmd != Common.CMD_FILE_LIST: return

            new_entries = []
            if payload:
                for line in payload.decode().split("\n"):
                    parts = line.split("|")
                    if len(parts) >= 4:
                        is_owner = parts[2] == "1"
                        is_shared = parts[3] == "1"

                        # --- הלוגיקה החדשה: הצג רק אם אני הבעלים או שזה שותף איתי ---
                        if is_owner or is_shared:
                            new_entries.append({
                                "name": parts[0],
                                "private": parts[1] == "1",
                                "is_owner": is_owner,
                                "shared": is_shared,
                                "size": int(parts[4]) if len(parts) > 4 else 512000
                            })

            self.all_entries = new_entries
            self.window.after(0, self._render_files)
        except Exception as e:
            self._status(f"Refresh error: {e}", "#E24B4A")

    def _render_files(self):
        for w in self.browser_frame.winfo_children(): w.destroy()

        search_query = self.search_entry.get().lower() if hasattr(self, 'search_entry') else ""
        filtered = [e for e in self.all_entries if search_query in e["name"].lower()]

        # עדכון מד האחסון לפי כל הקבצים
        total_bytes = sum(e["size"] for e in self.all_entries)
        usage = min(1.0, total_bytes / (100 * 1024 * 1024))
        self.storage_bar.set(usage)
        self.storage_label.configure(text=f"Storage Usage: {total_bytes / (1024 * 1024):.2f} MB / 100 MB")

        if not filtered:
            ctk.CTkLabel(self.browser_frame, text="No files found.", text_color="gray").pack(pady=20)
            return

        for e in filtered:
            row = ctk.CTkFrame(self.browser_frame, fg_color=("gray90", "gray20"))
            row.pack(fill="x", pady=2, padx=2)

            lbl = e["name"] + (" [shared]" if e["shared"] else " [private]" if e["private"] else "")
            ctk.CTkLabel(row, text=lbl, anchor="w").pack(side="left", padx=10, expand=True, fill="x")

            ctk.CTkButton(row, text="↓", width=30,
                          command=lambda n=e["name"]: threading.Thread(target=self._do_download, args=(n,),
                                                                       daemon=True).start()).pack(side="right", padx=2)
            if e["is_owner"]:
                ctk.CTkButton(row, text="🔗", width=30, command=lambda n=e["name"]: self._do_share(n)).pack(side="right",
                                                                                                           padx=2)
                ctk.CTkButton(row, text="✕", width=30, fg_color="#E24B4A",
                              command=lambda n=e["name"]: self._do_delete(n)).pack(side="right", padx=2)

    def _do_download(self, filename):
        try:
            self.conn.send(Common.CMD_GET_FILE, filename.encode())
            full_data = b""
            while True:
                cmd, payload = self.conn.recv_one()
                if cmd != Common.CMD_FILE_CHUNK_SRV: break
                cipher = AES.new(self.conn.aes_key, AES.MODE_EAX, nonce=payload[:16])
                full_data += cipher.decrypt_and_verify(payload[16:-16], payload[-16:])
                if len(payload[16:-16]) < CHUNK_SIZE: break

            path = filedialog.asksaveasfilename(initialfile=filename)
            if path:
                with open(path, "wb") as f: f.write(full_data)
                self._status(f"Saved to {os.path.basename(path)}", "#1D9E75")
        except:
            self._status("Download failed", "#E24B4A")

    def _do_share(self, filename):
        target = ctk.CTkInputDialog(text=f"Share '{filename}' with:", title="Share").get_input()
        if target:
            try:
                p = len(filename.encode()).to_bytes(1, "big") + filename.encode() + target.encode()
                cmd, _ = self._safe_send_recv(Common.CMD_SHARE_FILE, p)
                if cmd == Common.CMD_SHARE_OK: self._status("Shared!", "#1D9E75")
            except:
                pass

    def _do_delete(self, filename):
        try:
            cmd, _ = self._safe_send_recv(Common.CMD_DELETE_FILE, filename.encode())
            if cmd == Common.CMD_DELETE_OK: self._refresh_list()
        except:
            pass

    def run(self):
        self.window.mainloop()


if __name__ == "__main__":
    EncryptedFileClient().run()