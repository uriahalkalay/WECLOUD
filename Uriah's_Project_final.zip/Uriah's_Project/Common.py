HEADER_SIZE = 5

# client - server
CMD_LOGIN = 0
CMD_LOGOUT = 1
CMD_GET_FILE = 2
CMD_FILE_CHUNK = 3
CMD_REGISTER = 4
CMD_LIST_FILES = 5
CMD_DELETE_FILE = 6
CMD_RENAME_FILE = 7
CMD_SHARE_FILE = 8
CMD_LIST_SHARES = 9

# server - client
CMD_LOGIN_OK = 10
CMD_LOGIN_FAIL = 11
CMD_FILE_CHUNK_SRV = 12
CMD_UPLOAD_OK = 13
CMD_FILE_LIST = 14
CMD_REG_OK = 15
CMD_REG_FAIL = 16
CMD_FILE_NOT_FOUND = 17
CMD_DELETE_OK = 18
CMD_DELETE_FAIL = 19
CMD_RENAME_OK = 20
CMD_RENAME_FAIL = 21
CMD_SHARE_OK = 22
CMD_SHARE_FAIL = 23
CMD_INTEGRITY_OK = 24
CMD_INTEGRITY_FAIL = 25
CMD_RATE_LIMITED = 26


def build_message(cmd: int, data: bytes) -> bytes:
    if not isinstance(data, bytes):
        raise TypeError(f"build_message: data must be bytes, got {type(data)}")
    return cmd.to_bytes(1, "big") + len(data).to_bytes(4, "big") + data


def try_parse_message(buf: bytes):
    if len(buf) < HEADER_SIZE:
        return None, None
    cmd    = buf[0]
    length = int.from_bytes(buf[1:5], "big")
    if len(buf) < HEADER_SIZE + length:
        return None, None
    return cmd, buf[HEADER_SIZE: HEADER_SIZE + length]

